<?php

namespace App\Http\Controllers;

use App\Models\Profile;
use Illuminate\Http\Request;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Contract\Storage;
use Illuminate\Support\Facades\Storage as LaravelStorage;

class HoroscopeController extends Controller
{
    protected $firebaseStorage;

    public function __construct()
    {
        $this->firebaseStorage = (new Factory)
            ->withServiceAccount(config('services.firebase.credentials'))
            ->createStorage();
    }

    public function uploadHoroscope(Request $request)
    {
        $request->validate([
            'user_pmid' => 'required|exists:profiles,user_pmid',
            'horoscope' => 'required|file|mimes:pdf|max:2048',
        ]);

        $file = $request->file('horoscope');
        $userPmid = $request->input('user_pmid');
        $fileName = "{$userPmid}-horoscope.pdf";
        $firebasePath = "paraiyarmatching/assets/pdf/{$userPmid}/{$fileName}";

        try {
            // Upload file to Firebase Storage
            $bucket = $this->firebaseStorage->getBucket();
            $object = $bucket->upload(
                file_get_contents($file->getRealPath()),
                [
                    'name' => $firebasePath,
                ]
            );

            // Generate a download URL
            $expiresAt = new \DateTime('tomorrow');
            $horoscopeUrl = $object->signedUrl($expiresAt);

            // Update profile with the horoscope URL
            $profile = Profile::where('user_pmid', $userPmid)->first();
            $profile->update([
                'horoscope_url' => $horoscopeUrl,
            ]);

            return response()->json([
                'message' => 'Horoscope uploaded successfully.',
                'horoscope_url' => $horoscopeUrl,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to upload horoscope.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}