<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

class SuccessfulLoginNotification extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $login_time;
    public $browser_info;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($login_time, $browser_info)
    {
        $this->login_time = $login_time;
        $this->browser_info = $browser_info;
    }

    /**
     * Build the message.
     *
     * @return $this
     */

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Login Notification from ' . config('app.name'),
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'mails.successful_login',
        );
    }


    public function build()
    {
        return $this->markdown('mails.successful_login')
            ->subject('Login Notification from ' . config('app.name'));
    }
}
