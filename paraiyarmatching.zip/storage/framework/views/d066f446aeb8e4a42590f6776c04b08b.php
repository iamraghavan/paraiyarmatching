
<?php
    use Illuminate\Support\Facades\Http;

    function fetch_ip()
    {
        try {
            $response = Http::get('https://ipinfo.io/json');

            if ($response->successful()) {
                $data = $response->json();
                $clientIP = $data['ip'];
                $timezone = $data['timezone'];
                $country = $data['country'];

                return [
                    'ip' => $clientIP,
                    'timezone' => $timezone,
                    'country' => $country,
                ];
            } else {
                return ['error' => 'Unable to fetch IP information'];
            }
        } catch (\Exception $e) {
            return ['error' => 'Sorry Please Refresh the Page to get IP information'];
        }
    }

    $ipInfo = fetch_ip();
?>

<div>
    <div class="head-top">
        <div class="container">
            <div class="row">
                <div class="lhs">
                    <ul>

                        <?php if(isset($ipInfo['error'])): ?>
                        <li><a href="<?php echo e($ipInfo['error']); ?>"><?php echo e($ipInfo['error']); ?></a></li>
                        <?php else: ?>
                        <li><a href="<?php echo e($ipInfo['ip']); ?>"><?php echo e($ipInfo['ip']); ?></a></li>
                        <?php endif; ?>



                    </ul>
                </div>
                <div class="rhs">
                    <ul>
                        <li><a><span id="datetimes" style="display: inline;"></span></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="hom-top">
    <div class="container">
        <div class="row">
            <div class="hom-nav">
                <!-- LOGO -->
                <div class="logo">
                    
                    <a href="<?php echo e(url("/")); ?>" class="logo-brand"><img src="<?php echo e(asset("/images/logo-b.png")); ?>" alt="" loading="lazy"
                            class="ic-logo"></a>
                </div>

                <!-- EXPLORE MENU -->
                <div class="bl">
                    <ul>

                        <li class="smenu-pare">
                            <span class="smenu">Partner Search</span>
                            <div class="smenu-open smenu-box">
                                <div class="container">
                                    <div class="row">
                                        <h4 class="tit">Search your Life Partner</h4>
                                        <ul>
                                            <li>
                                                <div class="menu-box menu-box-2">
                                                    <h5> Brides <span>1200+ Verified profiles</span></h5>
                                                    <span class="explor-cta">More details</span>
                                                    <a href="<?php echo e(url("/")); ?>" class="fclick"></a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="menu-box menu-box-1">
                                                    <h5>Grooms <span>1100+ Verified profiles</span></h5>
                                                    <span class="explor-cta">More details</span>
                                                    <a href="<?php echo e(url("wedding.html")); ?>" class="fclick"></a>
                                                </div>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>


                            <li><a href="<?php echo e(url("#")); ?>">Take a Tour</a></li>

                            <li><a href="<?php echo e(url("/membership/package")); ?>">Membership Package</a></li>


                        <?php if(auth()->check()): ?>
                            <li><a onclick="confirmLogout()">Logout</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(url("/app/register")); ?>">Register</a></li>
                            <li><a href="<?php echo e(url("/app/login")); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="al">
                <!-- USER PROFILE -->
                <?php if(auth()->check()): ?>

                <a href="<?php echo e(url('/app/profile/dashboard')); ?>" rel="noopener noreferrer" name=<?php echo e(auth()->user()->name); ?> target="_parent" referrerpolicy="no-referrer strict-origin-when-cross-origin">
                    <div class="desktop-view"> <!-- Add a class for desktop view -->

                            <div class="head-pro">

                                <b><?php echo e(auth()->user()->name); ?></b><br>
                                <h4><?php echo e(auth()->user()->pmid); ?></h4>
                                <span class="fclick"></span>

                            </div>

                    </div>

                </a>

            <?php else: ?>

                    <div class="head-pro">
                        
                        <b><h6 id="datetimes" style="display: inline;"></h6></b><br>
                    </div>

            <?php endif; ?>
        </div>





                <!--MOBILE MENU-->
                <div class="mob-menu">
                    <div class="mob-me-ic">
                        
                        <?php if(auth()->check()): ?>

                        <a href="<?php echo e(url('/app/profile/dashboard')); ?>">
                            <span class="mobile-exprt" data-mob="dashbord">
                                <img src="<?php echo e(asset("/images/icon/users.svg")); ?>" alt="">
                            </span>
        </a>
        <?php endif; ?>

                        <span class="mobile-menu" data-mob="mobile">
                            <img src="<?php echo e(asset("/images/icon/menu.svg")); ?>" alt="">
                        </span>
                    </div>
                </div>
                <!--END MOBILE MENU-->
            </div>
        </div>
    </div>
</div>


   <!-- EXPLORE MENU POPUP -->
   <div class="mob-me-all mobile_menu">
    <div class="mob-me-clo"><img src="<?php echo e(asset("/images/icon/close.svg")); ?>" alt=""></div>
     <?php if(auth()->check()): ?>
                            <?php if(isset($ipInfo['error'])): ?>
                                <p>Error fetching IP information: <?php echo e($ipInfo['error']); ?></p>
                            <?php else: ?>
                                <li><p><?php echo e($ipInfo['ip']); ?></p></li>
                            <?php endif; ?>
                        <?php else: ?>
    <div class="mv-bus">
        <h4><i class="fa fa-globe" aria-hidden="true"></i> EXPLORE CATEGORY</h4>
        <ul>
            <li><a href="<?php echo e(url("#")); ?>">Search Brides</a></li>
            <li><a href="<?php echo e(url("#")); ?>">Search Grooms</a></li>

        </ul>
        <h4><i class="fa fa-align-center" aria-hidden="true"></i> All Pages</h4>
        <ul>
            <li><a href="<?php echo e(url("#")); ?>">Contact</a></li>
            <li><a href="<?php echo e(url("#")); ?>">Take a Tour</a></li>
            <li><a href="<?php echo e(url("#")); ?>">Help</a></li>

            <?php endif; ?>

            <?php if(auth()->check()): ?>
            <li><a onclick="confirmLogout()">Logout</a></li>
<?php else: ?>
<li><a href="<?php echo e(url("/app/register")); ?>">Register</a></li>
<li><a href="<?php echo e(url("/app/login")); ?>">Login</a></li>
<?php endif; ?>
        </ul>


    </div>
</div>


<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/components/header-top.blade.php ENDPATH**/ ?>