<?php $__env->startComponent('mail::message'); ?>
# Welcome to Our Platform!

Dear <?php echo e($userName); ?>,

We are delighted to welcome you to our platform. Your Aadhaar number ends with <b> **** **** <?php echo e($aadhaarLastFourDigits); ?></b>. Thank you for joining us!

<br>

If you have any questions or concerns about your account or our security measures, please do not hesitate to contact our support team at [support@paraiyarmatching.com](mailto:support@paraiyarmatching.com).

### Thank You

Thank you for choosing Paraiyar Matching, and we hope you have a great experience on our platform.

Best regards,
<br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/mails/welcome.blade.php ENDPATH**/ ?>