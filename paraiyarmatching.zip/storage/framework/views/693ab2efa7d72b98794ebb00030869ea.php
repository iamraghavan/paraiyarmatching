<?php $__env->startSection('content'); ?>

<!-- REGISTER -->
<section>
    <div class="login">
        <div class="container">
            <div class="row">
                <div class="inn">
                    <div class="lhs">
                        <div class="tit">
                            <h2>Now <b>Find your life partner</b> Easy and fast.</h2>
                        </div>
                        <div class="im">
                            <img src="<?php echo e(asset('images/login-couple.png')); ?>" alt="PMAT01">
                        </div>
                        <div class="log-bg">&nbsp;</div>
                    </div>
                    <div class="rhs">
                        <div>
                            <div class="form-tit">
                                <h4>Start for free</h4>
                                <h1>Sign up to Matrimony</h1>
                                <p>Already a member? <a href="<?php echo e(url('/app/login')); ?>">Login</a></p>
                            </div>
                            <div class="form-login">
                                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <div class="form-group">
                                        <label class="lb" for="name">Name:</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="Enter your full name" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb">Gender</label>
                                        <div class="gender-icons">
                                            <label for="male">
                                                <input type="radio" id="male" name="gender" value="male" class="<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="display: none;" <?php echo e(old('gender') == 'male' ? 'checked' : ''); ?>>
                                                <img src="https://cdn-icons-png.flaticon.com/512/9220/9220623.png" alt="Male" title="Male"> <p>male</p>
                                            </label>
                                            <label for="female">
                                                <input type="radio" id="female" name="gender" value="female" class="<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="display: none;" <?php echo e(old('gender') == 'female' ? 'checked' : ''); ?>>
                                                <img src="https://cdn-icons-png.flaticon.com/512/1019/1019173.png" alt="Female" title="Female"> <p>female</p>
                                            </label>
                                        </div>
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb" for="email">Email:</label>
                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Enter email" name="email" value="<?php echo e(old('email')); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="email-error"></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb" for="phone">Phone:</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" placeholder="Enter phone number" name="phone" value="<?php echo e(old('phone')); ?>" required maxlength="10">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="phone-error"></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb" for="aadhar_image">Upload Aadhar Card: <span style="color:red">*Aadhar Front Photo / Image</span></label>
                                        <input required type="file" id="imageInput" accept=".jpg, .jpeg, .png" onchange="uploadImage(event)" class="form-control <?php $__errorArgs = ['aadhar_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="aadhar_image" value="<?php echo e(old('aadhar_image')); ?>" required maxlength="14">
                                        <?php $__errorArgs = ['aadhar_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="aadhaar-number-error"></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb" for="aadhaar_number">Aadhaar Number:</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['aadhaar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aadhaar_number" placeholder="Enter Aadhaar number" name="aadhaar_number" value="<?php echo e(old('aadhaar_number')); ?>" required maxlength="14">
                                        <?php $__errorArgs = ['aadhaar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="aadhaar-number-error"></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="lb" for="password">Password:</label>
                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="Enter password" name="password" required>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <span class="invalid-feedback" id="password-error"></span>
                                    </div>

                                    <div class="form-group form-check">
                                        <input style="height: 1.1rem !important;" class="form-check-input <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="agree" id="agree" <?php echo e(old('agree') ? 'checked' : ''); ?> required>
                                        <label class="form-check-label" for="agree">
                                            <a href="#!">Terms of Service</a>, Privacy Policy,
                                        </label>
                                        <?php $__errorArgs = ['agree'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <button type="submit" id="submit-btn" class="btn btn-primary" disabled>Create Account</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END -->

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script>
    function uploadImage(event) {
        const input = event.target;
        const file = input.files[0];

        if (!file) {
            alert('Please select an image file.');
            return;
        }

        const reader = new FileReader();

        reader.onload = function(event) {
            const image = new Image();
            image.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                // Determine canvas dimensions based on image orientation
                if (image.width > image.height) {
                    canvas.width = 800; // Landscape image width
                    canvas.height = (image.height / image.width) * 800;
                } else {
                    canvas.width = 800; // Portrait image height
                    canvas.height = (image.height / image.width) * 800;
                }

                // Draw image on canvas
                ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

                // Convert canvas to base64 data URL
                const imageBase64 = canvas.toDataURL('image/jpeg');

                // Run Tesseract OCR on the image
                Tesseract.recognize(
                    imageBase64,
                    'eng', // Language - you can change to other languages as needed
                    { logger: m => console.log(m) } // Optional logger function
                ).then(({ data: { text } }) => {
                    // Extract Aadhaar number from OCR result
                    const regex = /\d{4}\s\d{4}\s\d{4}/;
                    const matches = text.match(regex);
                    const aadhaarNumber = matches ? matches[0] : 'Not found';

                    // Update the UI with the extracted Aadhaar number
                    const aadhaarNumberInput = document.getElementById('aadhaar_number');
                    if (aadhaarNumberInput) {
                        if (aadhaarNumber === 'Not found') {
                            Swal.fire({
                                icon: 'info',
                                title: 'Aadhaar Number Not Detected',
                                text: 'Please upload a horizontally aligned top photo/image of your Aadhaar card.',
                                imageUrl: '<?php echo e(asset('images/aadhaar-instruction.webp')); ?>',
                                imageWidth: 700,
                                imageHeight: 200,
                                imageAlt: 'Aadhaar Instructions'
                            });
                        } else {
                            aadhaarNumberInput.value = aadhaarNumber;
                        }
                    }

                }).catch(error => {
                    console.error('Error during OCR:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to extract Aadhaar number. Please try again.'
                    });
                });
            };

            // Load the selected image
            image.src = event.target.result;
        };

        reader.readAsDataURL(file);
    }
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const emailInput = document.getElementById('email');
        const phoneInput = document.getElementById('phone');
        const passwordInput = document.getElementById('password');
        const aadhaarNumberInput = document.getElementById('aadhaar_number');
        const submitBtn = document.getElementById('submit-btn');

        const emailError = document.getElementById('email-error');
        const phoneError = document.getElementById('phone-error');
        const passwordError = document.getElementById('password-error');
        const aadhaarNumberError = document.getElementById('aadhaar-number-error');

        const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail|outlook|hotmail)\.[a-zA-Z]{2,}$/; // Only allow gmail, outlook, hotmail domains
        const phoneRegex = /^\d{10}$/; // Exactly 10 digits
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/; // Minimum 8 characters, include a letter, a number, and a special character
        const aadhaarRegex = /^\d{4} \d{4} \d{4}$/; // Format: 1111 1111 1111

        function formatAadhaar(aadhaar) {
            return aadhaar.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
        }

        function validateEmail() {
            const email = emailInput.value.trim().toLowerCase(); // Trim whitespace and convert to lowercase
            if (!emailRegex.test(email)) {
                emailError.textContent = 'Please enter a valid Gmail, Outlook, or Hotmail email address.';
                emailInput.classList.add('is-invalid');
                return false;
            } else {
                emailError.textContent = '';
                emailInput.classList.remove('is-invalid');
                return true;
            }
        }

        function validatePhone() {
            const phone = phoneInput.value.trim(); // Trim whitespace
            if (!phoneRegex.test(phone)) {
                phoneError.textContent = 'Please enter a valid 10-digit phone number.';
                phoneInput.classList.add('is-invalid');
                return false;
            } else {
                phoneError.textContent = '';
                phoneInput.classList.remove('is-invalid');
                return true;
            }
        }

        function validateAadhaarNumber() {
            let aadhaarNumber = aadhaarNumberInput.value.replace(/\s+/g, ''); // Remove spaces
            aadhaarNumber = aadhaarNumber.replace(/(.{4})/g, '$1 ').trim(); // Add spaces every 4 digits
            aadhaarNumberInput.value = aadhaarNumber; // Format Aadhaar number
            if (!aadhaarRegex.test(aadhaarNumber)) {
                aadhaarNumberError.textContent = 'Please enter a valid Aadhaar number in the format: 1111 1111 1111.';
                aadhaarNumberInput.classList.add('is-invalid');
                return false;
            } else {
                aadhaarNumberError.textContent = '';
                aadhaarNumberInput.classList.remove('is-invalid');
                return true;
            }
        }

        function validatePassword() {
            const password = passwordInput.value;
            if (!passwordRegex.test(password)) {
                passwordError.textContent = 'Password must be at least 8 characters long, include a letter, a number, and a special character.';
                passwordInput.classList.add('is-invalid');
                return false;
            } else {
                passwordError.textContent = '';
                passwordInput.classList.remove('is-invalid');
                return true;
            }
        }

        function validateForm() {
            const isEmailValid = validateEmail();
            const isPhoneValid = validatePhone();
            const isAadhaarNumberValid = validateAadhaarNumber();
            const isPasswordValid = validatePassword();
            submitBtn.disabled = !(isEmailValid && isPhoneValid && isAadhaarNumberValid && isPasswordValid);
        }

        emailInput.addEventListener('blur', validateEmail);
        phoneInput.addEventListener('blur', validatePhone);
        aadhaarNumberInput.addEventListener('blur', validateAadhaarNumber);
        passwordInput.addEventListener('blur', validatePassword);

        emailInput.addEventListener('input', validateForm);
        phoneInput.addEventListener('input', validateForm);
        aadhaarNumberInput.addEventListener('input', validateForm);
        passwordInput.addEventListener('input', validateForm);
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/auth/register.blade.php ENDPATH**/ ?>