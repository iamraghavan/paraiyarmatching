<?php $__env->startSection('dashboard-content'); ?>



<script>
  function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById('preview_image');
            output.src = reader.result;
            output.style.display = 'block'; // Show the image preview
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

<section>
    <div class="login pro-edit-update">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-lg-3">
                    <div class="db-nav">
                        <div class="db-nav-pro">

                            <?php if(empty($profile) || empty($profile->profile_image)): ?>
                            <?php if($user->gender === 'male'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/11195/11195340.png" alt="Male Profile Image" class="default-profile-image">
                            <?php elseif($user->gender === 'female'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/13979/13979770.png" alt="Female Profile Image" class="default-profile-image">
                            <?php endif; ?>
                        <?php else: ?>
                            <img id="" src="<?php echo e(url($profile->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="" >
                        <?php endif; ?>


                        </div>
                        <div class="db-nav-list">
                            <ul>
                                <li><a href="<?php echo e(url('/app/profile/dashboard')); ?>" class="act"><i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard</a></li>

                                <li><a href="<?php echo e(url('/app/gallery/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Gallery</a></li>
                                <li><a href="<?php echo e(url('/app/horoscope/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Horoscope</a></li>
                                <li><a href="<?php echo e(url('/app/f/'. $user->pmid .'/membership-plan')); ?>"><i class="fa fa-money" aria-hidden="true"></i>Plan</a></li>
                                    <?php
                                    function generateRandomString($length = 100) {
                                        return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', $length)), 0, $length);
                                    }

                                    $randomString = generateRandomString(); // Creates a long random alphanumeric string
                                    $salt = 'pmat'; // You can generate a more secure salt or use a constant
                                    $saltedString = $randomString . $salt;
                                    $hashedString = hash('sha256', $saltedString); // Hash the salted string using SHA-256
                                ?>

                                <li>
                                    <a href="<?php echo e(url('/app/profile/user-profile-edit/' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Profile
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/app/profile/edit-personal-data/' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Personal Data
                                    </a>
                                </li>


                                <li><a onclick="confirmLogout()"><i class="fa fa-sign-out" aria-hidden="true"></i>Log out</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="row">

                <div class="inn">
                    <div class="rhs">
                        <div class="form-login">
                            <form method="POST" action="<?php echo e(route('profile.bio')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <input type="hidden" value="<?php echo e($user->pmid); ?>" name="user_pmid">

                                <!-- PROFILE BIO -->
                                <div class="edit-pro-parti">
                                    <div class="form-tit">
                                        <h4><?php echo e($user->pmid); ?></h4>
                                        <h1>Profile / Update</h1>
                                    </div>
                                    <div class="form-group">
                                        <label class="lb">Bio:</label>
                                        <textarea class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your Bio"
                                            name="bio" required><?php echo e(old('bio', $profile->my_bio ?? '')); ?></textarea>
                                        <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>



                                    <div class="row mb-3">
                                        <div class="col-md-6 form-group">
                                            <label for="raasi" class="form-label">Raasi:</label>
                                            <select class="form-select" id="raasi" name="raasi" onchange="populateStars(this)">
                                                <option value="">Select Raasi</option>
                                                <option value="Mesham" <?php echo e(old('raasi', optional($profile)->raasi) === 'Mesham' ? 'selected' : ''); ?>>மேஷம் (Mesham)</option>
                                                <option value="Rishabam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Rishabam' ? 'selected' : ''); ?>>ரிஷபம் (Rishabam)</option>
                                                <option value="Midhunam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Midhunam' ? 'selected' : ''); ?>>மிதுனம் (Midhunam)</option>
                                                <option value="Kadagam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Kadagam' ? 'selected' : ''); ?>>கடகம் (Kadagam)</option>
                                                <option value="Simham" <?php echo e(old('raasi', optional($profile)->raasi) === 'Simham' ? 'selected' : ''); ?>>சிம்மம் (Simham)</option>
                                                <option value="Kanni" <?php echo e(old('raasi', optional($profile)->raasi) === 'Kanni' ? 'selected' : ''); ?>>கன்னி (Kanni)</option>
                                                <option value="Thulam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Thulam' ? 'selected' : ''); ?>>துலாம் (Thulam)</option>
                                                <option value="Viruchigam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Viruchigam' ? 'selected' : ''); ?>>விருச்சிகம் (Viruchigam)</option>
                                                <option value="Dhanusu" <?php echo e(old('raasi', optional($profile)->raasi) === 'Dhanusu' ? 'selected' : ''); ?>>தனுசு (Dhanusu)</option>
                                                <option value="Magaram" <?php echo e(old('raasi', optional($profile)->raasi) === 'Magaram' ? 'selected' : ''); ?>>மகரம் (Magaram)</option>
                                                <option value="Kumbam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Kumbam' ? 'selected' : ''); ?>>கும்பம் (Kumbam)</option>
                                                <option value="Meenam" <?php echo e(old('raasi', optional($profile)->raasi) === 'Meenam' ? 'selected' : ''); ?>>மீனம் (Meenam)</option>
                                            </select>
                                            <?php $__errorArgs = ['raasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6 form-group">
                                            <label for="star" class="form-label">Star:</label>
                                            <select class="form-select" id="star" name="star">
                                                <option value="">Select Star</option>
                                                <!-- Star options will be dynamically populated based on the selected Raasi -->
                                            </select>
                                            <?php $__errorArgs = ['star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="row mb-3">
                                        <div class="col-md-6 form-group">
                                            <label for="diet">Diet Preference</label>
                                            <div>
                                                <label class="diet-option">
                                                    <input type="radio" name="diet" value="vegetarian" <?php echo e(old('diet', $profile->diet) == 'vegetarian' ? 'checked' : ''); ?>>
                                                    <i class="fa fa-leaf" aria-hidden="true"></i> Vegetarian
                                                </label>
                                                <label class="diet-option">
                                                    <input type="radio" name="diet" value="non_vegetarian" <?php echo e(old('diet', $profile->diet) == 'non_vegetarian' ? 'checked' : ''); ?>>
                                                    <i class="fa fa-drumstick-bite" aria-hidden="true"></i> Non-Vegetarian
                                                </label>
                                                <label class="diet-option">
                                                    <input type="radio" name="diet" value="vegan" <?php echo e(old('diet', $profile->diet) == 'vegan' ? 'checked' : ''); ?>>
                                                    <i class="fa fa-carrot" aria-hidden="true"></i> Vegan
                                                </label>
                                            </div>
                                        </div>
                                    </div>


                                    <script>
                                        // Function to populate stars based on selected Raasi
                                        function populateStars(raasiSelect) {
                                            var raasi = raasiSelect.value;
                                            var starSelect = document.getElementById("star");
                                            // Clear existing options
                                            starSelect.innerHTML = '<option value="">Select Star</option>';

                                            // Define star options based on Raasi
                                            var starOptions = [];
                                            switch (raasi) {
                                                case "Mesham":
                                                    starOptions = ["Asvini அஸ்வினி", "Baraṇi பரணி", "Kārthigai கார்த்திகை"];
                                                    break;
                                                case "Rishabam":
                                                    starOptions = ["Kārthigai 2-ஆம் பாதம் கிருத்திகை", "Rōgiṇi ரோகிணி", "Mirugasīriḍam 2-ஆம் பாதம் மிருகசீரிடம்"];
                                                    break;
                                                case "Midhunam":
                                                    starOptions = ["Mirugasīriḍam 3-ஆம் பாதம் மிருகசீரிடம்", "Tiruvādirai திருவாதிரை", "Puṉarpūsam 3-ஆம் பாதம் புனர்பூசம்"];
                                                    break;
                                                case "Kadagam":
                                                    starOptions = ["Puṉarpūsam 4-ஆம் பாதம் புனர்பூசம்", "Pūsam பூசம்", "Āyilyam ஆயில்யம்"];
                                                    break;
                                                case "Simham":
                                                    starOptions = ["Magam மகம்", "Pūram பூரம்", "Uttiram 1-ஆம் பாதம் உத்திரம்"];
                                                    break;
                                                case "Kanni":
                                                    starOptions = ["Uttiram 2-ஆம் பாதம் உத்திரம்", "Asttam அஸ்தம்", "Cittirai 2-ஆம் பாதம் சித்திரை"];
                                                    break;
                                                case "Thulam":
                                                    starOptions = ["Cittirai 3-ஆம் பாதம் சித்திரை", "Suvāti சுவாதி", "Visākam 3-ஆம் பாதம் விசாகம்"];
                                                    break;
                                                case "Viruchigam":
                                                    starOptions = ["Visākam 4-ஆம் பாதம் விசாகம்", "Anusham அனுஷம்", "Kēṭṭai கேட்டை"];
                                                    break;
                                                case "Dhanusu":
                                                    starOptions = ["Mūlam மூலம்", "Pūrāṭam பூராடம்", "Uttirāṭam 1-ஆம் பாதம் உத்திராடம்"];
                                                    break;
                                                case "Magaram":
                                                    starOptions = ["Uttirāṭam 2-ஆம் பாதம் உத்திராடம்", "Tiruvōnam திருவோணம்", "Aviṭṭam 2-ஆம் பாதம் அவிட்டம்"];
                                                    break;
                                                case "Kumbam":
                                                    starOptions = ["Aviṭṭam 3-ஆம் பாதம் அவிட்டம்", "Sadayam சதயம்", "Pūraṭṭādi 3-ஆம் பாதம் பூரட்டாதி"];
                                                    break;
                                                case "Meenam":
                                                    starOptions = ["Pūraṭṭādi 4-ஆம் பாதம் பூரட்டாதி", "Uttiraṭṭādi உத்திரட்டாதி", "Rēvati ரேவதி"];
                                                    break;
                                            }

                                            // Populate the star select options
                                            starOptions.forEach(function(star) {
                                                var option = document.createElement("option");
                                                option.value = star.split(' ')[0]; // Extracting star name without Tamil translation
                                                option.textContent = star;
                                                if (option.value === "<?php echo e(old('star', optional($profile)->star)); ?>") {
                                                    option.selected = true;
                                                }
                                                starSelect.appendChild(option);
                                            });
                                        }

                                        // Populate stars on page load if there is a selected Raasi
                                        window.onload = function() {
                                            var raasiSelect = document.getElementById("raasi");
                                            if (raasiSelect.value !== "") {
                                                populateStars(raasiSelect);
                                            }
                                        };
                                    </script>



                                    <div class="row mb-3">
                                        <div class="col-md-6 form-group">
                                            <label for="dosham" class="form-label">Dosham:</label>
                                            <select class="form-select" id="dosham" name="dosham">
                                                <option value="">Select Dosham</option>
                                                <option value="No Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'No Dosham' ? 'selected' : ''); ?>>No Dosham</option>
                                                <option value="Chevvai Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Chevvai Dosham' ? 'selected' : ''); ?>>Chevvai Dosham</option>
                                                <option value="Rahu Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Rahu Dosham' ? 'selected' : ''); ?>>Rahu Dosham</option>
                                                <option value="Kethu Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Kethu Dosham' ? 'selected' : ''); ?>>Kethu Dosham</option>
                                                <option value="Sarpa Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Sarpa Dosham' ? 'selected' : ''); ?>>Sarpa Dosham</option>
                                                <option value="Kalathra Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Kalathra Dosham' ? 'selected' : ''); ?>>Kalathra Dosham</option>
                                                <option value="Naga Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Naga Dosham' ? 'selected' : ''); ?>>Naga Dosham</option>
                                                <option value="Manglik Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Manglik Dosham' ? 'selected' : ''); ?>>Manglik Dosham</option>
                                                <option value="Pitru Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Pitru Dosham' ? 'selected' : ''); ?>>Pitru Dosham</option>
                                                <option value="Graha Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Graha Dosham' ? 'selected' : ''); ?>>Graha Dosham</option>
                                                <option value="Shani Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Shani Dosham' ? 'selected' : ''); ?>>Shani Dosham</option>
                                                <option value="Kuja Dosham" <?php echo e(old('dosham', optional($profile)->dosham) === 'Kuja Dosham' ? 'selected' : ''); ?>>Kuja Dosham</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                            <?php $__errorArgs = ['dosham'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>



                                    <?php
                                    $siblings = json_decode($profile->siblings ?? '[]', true);
                                ?>

                                <div class="row mb-3">
                                    <div class="col-md-6 form-group">
                                        <label for="number_of_siblings">Number of Siblings:</label>
                                        <input type="number" id="number_of_siblings" name="number_of_siblings" min="0" class="form-control" value="<?php echo e(old('number_of_siblings', count($siblings))); ?>">
                                    </div>
                                </div>
                                <div id="siblings_container" class="row">
                                    <?php $__currentLoopData = $siblings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6 mb-3 form-group">
                                            <label for="sibling_name_<?php echo e($index); ?>">Sibling Name:</label>
                                            <input type="text" id="sibling_name_<?php echo e($index); ?>" name="siblings[<?php echo e($index); ?>][name]" class="form-control" value="<?php echo e(old('siblings.'.$index.'.name', $sibling['name'])); ?>">
                                        </div>
                                        <div class="col-md-6 mb-3 form-group">
                                            <label for="sibling_married_<?php echo e($index); ?>">Married:</label>
                                            <select id="sibling_married_<?php echo e($index); ?>" name="siblings[<?php echo e($index); ?>][married]" class="form-control">
                                                <option value="1" <?php echo e(old('siblings.'.$index.'.married', $sibling['married']) == 1 ? 'selected' : ''); ?>>Yes</option>
                                                <option value="0" <?php echo e(old('siblings.'.$index.'.married', $sibling['married']) == 0 ? 'selected' : ''); ?>>No</option>
                                            </select>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                    <!-- Submit Button -->
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<script>
    $(document).ready(function() {
        const initialSiblings = <?php echo json_encode($siblings, 15, 512) ?>;
        renderSiblings(initialSiblings.length);

        $('#number_of_siblings').on('input', function() {
            const numSiblings = $(this).val();
            renderSiblings(numSiblings);
        });

        function renderSiblings(numSiblings) {
            $('#siblings_container').empty();
            for (let i = 0; i < numSiblings; i++) {
                const sibling = initialSiblings[i] || { name: '', married: '' };
                const siblingDiv = `
                    <div class="col-md-6 mb-3 form-group">
                        <label for="sibling_name_${i}">Sibling Name:</label>
                        <input type="text" id="sibling_name_${i}" name="siblings[${i}][name]" class="form-control" value="${sibling.name}">
                    </div>
                    <div class="col-md-6 mb-3 form-group">
                        <label for="sibling_married_${i}">Married:</label>
                        <select id="sibling_married_${i}" name="siblings[${i}][married]" class="form-control">
                            <option value="1" ${sibling.married == 1 ? 'selected' : ''}>Yes</option>
                            <option value="0" ${sibling.married == 0 ? 'selected' : ''}>No</option>
                        </select>
                    </div>
                `;
                $('#siblings_container').append(siblingDiv);
            }
        }
    });
</script>
<style>
    .diet-option {
        display: flex;
        align-items: center;
        margin-right: 15px;
        cursor: pointer;
    }

    .diet-option i {
        margin-right: 5px;
        font-size: 1.5em;
        color: #6c757d;
    }

    .diet-option input[type="radio"] {
        display: none; /* Hide the default radio button */
    }

    .diet-option input[type="radio"]:checked + i {
        color: #007bff; /* Change color when the radio button is checked */
    }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/pages/edit-personal-data.blade.php ENDPATH**/ ?>