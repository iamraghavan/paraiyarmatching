<?php $__env->startSection('dashboard-content'); ?>

<section>
    <div class="login pro-edit-update">
        <div class="container">
            <div class="row">
                <div class="inn">
                    <div class="rhs">
                        <div class="form-login">
                            <form action="<?php echo e(route('horoscope.uploads')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div>
                                    <label for="user_pmid">User PM ID:</label>
                                    <input type="text" id="user_pmid" value="<?php echo e($user->pmid); ?>" name="user_pmid" required>
                                </div>
                                <div>
                                    <label for="horoscope">Horoscope PDF:</label>
                                    <input type="file" id="horoscope" name="horoscope" accept="application/pdf" required>
                                </div>
                                <div>
                                    <button type="submit">Upload</button>
                                </div>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/pages/upload-horoscope.blade.php ENDPATH**/ ?>