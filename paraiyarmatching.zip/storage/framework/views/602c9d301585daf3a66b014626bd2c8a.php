<?php $__env->startSection('dashboard-content'); ?>
<section>
    <div class="db">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-lg-3">
                    <div class="db-nav">
                        <div class="db-nav-pro">

                            <?php if(empty($profile) || empty($profile->profile_image)): ?>
                            <?php if($user->gender === 'male'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/11195/11195340.png" alt="Male Profile Image" class="default-profile-image">
                            <?php elseif($user->gender === 'female'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/13979/13979770.png" alt="Female Profile Image" class="default-profile-image">
                            <?php endif; ?>
                        <?php else: ?>
                            <img id="" src="<?php echo e(url($profile->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="" >
                        <?php endif; ?>


                        </div>
                        <div class="db-nav-list">
                            <ul>
                                <li><a href="<?php echo e(url('/app/profile/dashboard')); ?>" class="act"><i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard</a></li>

                                <li><a href="<?php echo e(url('/app/gallery/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Gallery</a></li>
                                <li><a href="<?php echo e(url('/app/horoscope/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Horoscope</a></li>
                                <li><a href="<?php echo e(url('/app/f/'. $user->pmid .'/membership-plan')); ?>"><i class="fa fa-money" aria-hidden="true"></i>Plan</a></li>
                                    <?php
                                    function generateRandomString($length = 100) {
                                        return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', $length)), 0, $length);
                                    }

                                    $randomString = generateRandomString(); // Creates a long random alphanumeric string
                                    $salt = 'pmat'; // You can generate a more secure salt or use a constant
                                    $saltedString = $randomString . $salt;
                                    $hashedString = hash('sha256', $saltedString); // Hash the salted string using SHA-256
                                ?>

                                <li>
                                    <a href="<?php echo e(url('/app/profile/user-profile-edit' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Profile
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/app/profile/edit-personal-data' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Personal Data
                                    </a>
                                </li>


                                <li><a onclick="confirmLogout()"><i class="fa fa-sign-out" aria-hidden="true"></i>Log out</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="row">
                        <div class="col-md-3 db-sec-com">
                            <h2 class="db-tit">Plan details</h2>
                            <div class="db-pro-stat">
                                <h6 class="tit-top-curv">Current plan</h6>
                                <div class="db-plan-card">
                                    <img src="<?php echo e(asset('images/icon/plan.png')); ?>" alt="">
                                </div>
                                <div class="db-plan-detil">
                                    <ul>
                                        <?php if($userPayment): ?>

                                        <li>Name: <strong><?php echo e($userPayment->name); ?></strong></li>

                                        <?php if($userPayment->paid_status == 'Not Paid'): ?>
                                        <li>This user has a free membership.</li>
                                        <?php elseif($userPayment->paid_status == 'Paid'): ?>
                                        <li>Package Details: <strong><?php echo e($userPayment->package_details); ?></strong></li>
                                        <?php endif; ?>
                                        <li>Paid Status: <strong><?php echo e($userPayment->paid_status ? 'Paid' : 'Not Paid'); ?></strong></li>


                                        <?php if($isFreeMembership): ?>

                                        <li><a href="" class="cta-3">Upgrade now</a></li>

                                    <?php else: ?>
                                        <p>This user has a paid membership.</p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p>User payment details not found.</p>
                                <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9 db-sec-com">

                            <div class="db-invoice">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>User PMID</th>
                                            <th>Name</th>
                                            <th>Package Details</th>
                                            <th>Paid Status</th>
                                            <th>Date of Payment</th>
                                            <th>Plan Expiry Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($userPayment): ?>
                                            <tr>
                                                <td><?php echo e($userPayment->user_pmid); ?></td>
                                                <td><?php echo e($userPayment->name); ?></td>
                                                <td><?php echo e($userPayment->package_details); ?></td>
                                                <td><?php echo e($userPayment->paid_status ? 'Paid' : 'Not Paid'); ?></td>
                                                <?php if($userPayment->paid_status && $userPayment->package_details != '0 Months'): ?>
                                                <td><?php echo e(\Carbon\Carbon::parse($userPayment->date_of_paid)->format('d-m-Y')); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($userPayment->plan_expired_date)->format('d-m-Y')); ?></td>
                                            <?php else: ?>
                                                <td>--</td>
                                                <td>--</td>
                                            <?php endif; ?>
                                                
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6">No payment details found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                                </div>
                        </div>
                        <div class="col-md-12 db-sec-com">
                            <div class="alert alert-warning db-plan-canc">
                                <p><strong>Plan cancellation:</strong> <a href="#" data-bs-toggle="modal" data-bs-target="#plancancel">Click here</a> to cancell the current plan.</p>
                            </div>
                        </div>
                        <div class="col-md-12 db-sec-com">
                            <div class="alert alert-warning db-plan-canc db-plan-canc-app">
                                <p>Your plan cancellation request has been successfully received by the admin. Once the admin approves your cancellation, the cost will be sent to you.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/pages/plan.blade.php ENDPATH**/ ?>