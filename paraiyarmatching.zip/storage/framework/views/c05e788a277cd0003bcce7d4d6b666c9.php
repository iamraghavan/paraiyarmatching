<?php $__env->startSection('dashboard-content'); ?>



<script>
  function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function(){
            var output = document.getElementById('preview_image');
            output.src = reader.result;
            output.style.display = 'block'; // Show the image preview
        };
        reader.readAsDataURL(event.target.files[0]);
    }
</script>

<section>
    <div class="login pro-edit-update">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-lg-3">
                    <div class="db-nav">
                        <div class="db-nav-pro">

                            <?php if(empty($profile) || empty($profile->profile_image)): ?>
                            <?php if($user->gender === 'male'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/11195/11195340.png" alt="Male Profile Image" class="default-profile-image">
                            <?php elseif($user->gender === 'female'): ?>
                                <img id="" src="https://cdn-icons-png.freepik.com/512/13979/13979770.png" alt="Female Profile Image" class="default-profile-image">
                            <?php endif; ?>
                        <?php else: ?>
                            <img id="" src="<?php echo e(url($profile->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="" >
                        <?php endif; ?>


                        </div>
                        <div class="db-nav-list">
                            <ul>
                                <li><a href="<?php echo e(url('/app/profile/dashboard')); ?>" class="act"><i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard</a></li>

                                <li><a href="<?php echo e(url('/app/gallery/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Gallery</a></li>
                                <li><a href="<?php echo e(url('/app/horoscope/upload')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>Upload Horoscope</a></li>
                                <li><a href="<?php echo e(url('/app/f/'. $user->pmid .'/membership-plan')); ?>"><i class="fa fa-money" aria-hidden="true"></i>Plan</a></li>
                                    <?php
                                    function generateRandomString($length = 100) {
                                        return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', $length)), 0, $length);
                                    }

                                    $randomString = generateRandomString(); // Creates a long random alphanumeric string
                                    $salt = 'pmat'; // You can generate a more secure salt or use a constant
                                    $saltedString = $randomString . $salt;
                                    $hashedString = hash('sha256', $saltedString); // Hash the salted string using SHA-256
                                ?>

                                <li>
                                    <a href="<?php echo e(url('/app/profile/user-profile-edit/' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Profile
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/app/profile/edit-personal-data/' . $user->pmid . '/' . $hashedString)); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>Edit Personal Data
                                    </a>
                                </li>


                                <li><a onclick="confirmLogout()"><i class="fa fa-sign-out" aria-hidden="true"></i>Log out</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="row">

                <div class="inn">
                    <div class="rhs">
                        <div class="form-login">
                            <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input type="hidden" value="<?php echo e($user->pmid); ?>" name="user_pmid">

                                 <!--PROFILE BIO-->
                                 <div class="edit-pro-parti">
                                    <div class="form-tit">
                                        <h4><?php echo e($user->pmid); ?></h4>
                                        <h1>Profile / Update</h1>
                                    </div>
                                    <div class="form-group">
                                        <label class="lb">Name:</label>
                                        <input type="text" value="<?php echo e($user->name); ?>" class="form-control" placeholder="Enter your full name"
                                            name="name" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="lb">Email:</label>
                                        <input type="email" value="<?php echo e($user->email); ?>" class="form-control" id="email"
                                            placeholder="Enter email" name="email" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="lb">Phone:</label>
                                        <input type="number" value="<?php echo e($user->phone); ?>" class="form-control" id="phone"
                                            placeholder="Enter phone number" name="phone" readonly>
                                    </div>


                                    <div class="form-group">
                                        <label class="lb">Gender:</label>
                                        <input type="text" value="<?php echo e($user->gender); ?>" class="form-control" id="gender"
                                            placeholder="<?php echo e($user->gender); ?>" name="gender" readonly>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 form-group">
                                            <label class="lb">Upload Profile Picture:</label>

                                            <!-- <input type="file"
                                            class="custom-file-input form-control <?php if($errors->has('imagepath')): ?> is-invalid <?php endif; ?>"
                                            id="profile_image"
                                            name="profile_image"
                                            accept="image/*"
                                            onchange="previewImage(event)"> -->



<label for="images" class="drop-container">
    <span class="drop-title">Drop files here</span> or
    <input class="<?php if($errors->has('imagepath')): ?> is-invalid <?php endif; ?>" type="file" id="profile_image" onchange="previewImage(event)" name="profile_image" accept="image/*">
</label>


<?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                        </div>
                                        <div class="profile-image-container col-md-6">
                                            <?php if(empty($profile) || empty($profile->profile_image)): ?>
                                                <?php if($user->gender === 'male'): ?>
                                                    <img id="preview_image" src="https://cdn-icons-png.freepik.com/512/11195/11195340.png" alt="Male Profile Image" class="default-profile-image">
                                                <?php elseif($user->gender === 'female'): ?>
                                                    <img id="preview_image" src="https://cdn-icons-png.freepik.com/512/13979/13979770.png" alt="Female Profile Image" class="default-profile-image">
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <img id="preview_image" src="<?php echo e(url($profile->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="" >
                                            <?php endif; ?>
                                        </div>


                                    </div>

                                </div>
                                <!--END PROFILE BIO-->

                                <!-- Date of Birth -->


                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Date of Birth:</label>
                                        <input type="date" class="form-control" id="dob" name="dob" value="<?php echo e(old('dob', optional($profile)->dob ?? '')); ?>">
                                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="lb"><?php echo e($user->name); ?>, your Age is:</label>
                                        <input type="text" class="form-control" id="age" placeholder="Your age" value="<?php echo e(old('dob', optional($profile)->age ?? '')); ?>" readonly name="age">
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Father's Name:</label>
                                        <input type="text" class="form-control" id="father_name" name="father_name" value="<?php echo e(old('father_name', optional($profile)->father_name ?? '')); ?>">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Father's Occupation:</label>
                                        <input type="text" class="form-control" id="father_occupation" name="father_occupation" value="<?php echo e(old('father_occupation', optional($profile)->father_occupation ?? '')); ?>">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Mother's Name:</label>
                                        <input type="text" class="form-control" id="mother_name" name="mother_name" value="<?php echo e(old('mother_name', optional($profile)->mother_name ?? '')); ?>">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Mother's Occupation:</label>
                                        <input type="text" class="form-control" id="mother_occupation" name="mother_occupation" value="<?php echo e(old('mother_occupation', optional($profile)->mother_occupation ?? '')); ?>">
                                    </div>
                                </div>



                                <!-- Religion -->

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Religion:</label>
                                       <select class="form-select" name="religion">
    <option hidden>Select Religion</option>
    <option value="Hindu" <?php echo e(old('religion', optional($profile)->religion) == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
    
    <option value="Christian" <?php echo e(old('religion', optional($profile)->religion) == 'Christian' ? 'selected' : ''); ?>>Christian</option>
    
    <option value="Buddhist" <?php echo e(old('religion', optional($profile)->religion) == 'Buddhist' ? 'selected' : ''); ?>>Buddhist</option>
    
    <option value="No Religious Belief" <?php echo e(old('religion', optional($profile)->religion) == 'No Religious Belief' ? 'selected' : ''); ?>>No Religious Belief</option>
</select>


                                    <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>




                                    <div class="col-md-6 form-group">
                                        <label class="lb">Mother Tongue:</label>

                                        <select class="form-select" name="mother_tongue">
    <option value="">Select Mother Tongue</option>
    <option value="Hindi" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Hindi' ? 'selected' : ''); ?>>Hindi</option>
    <option value="Bengali" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Bengali' ? 'selected' : ''); ?>>Bengali</option>
    <option value="Telugu" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Telugu' ? 'selected' : ''); ?>>Telugu</option>
    <option value="Marathi" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Marathi' ? 'selected' : ''); ?>>Marathi</option>
    <option value="Tamil" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Tamil' ? 'selected' : ''); ?>>Tamil</option>
    <option value="Urdu" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Urdu' ? 'selected' : ''); ?>>Urdu</option>
    <option value="Gujarati" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Gujarati' ? 'selected' : ''); ?>>Gujarati</option>
    <option value="Kannada" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Kannada' ? 'selected' : ''); ?>>Kannada</option>
    <option value="Odia" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Odia' ? 'selected' : ''); ?>>Odia</option>
    <option value="Punjabi" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Punjabi' ? 'selected' : ''); ?>>Punjabi</option>
    <option value="Malayalam" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Malayalam' ? 'selected' : ''); ?>>Malayalam</option>
    <option value="Assamese" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Assamese' ? 'selected' : ''); ?>>Assamese</option>
    <option value="Sanskrit" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Sanskrit' ? 'selected' : ''); ?>>Sanskrit</option>
    <option value="Konkani" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Konkani' ? 'selected' : ''); ?>>Konkani</option>
    <option value="Manipuri" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Manipuri' ? 'selected' : ''); ?>>Manipuri</option>
    <option value="Nepali" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Nepali' ? 'selected' : ''); ?>>Nepali</option>
    <option value="Sindhi" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Sindhi' ? 'selected' : ''); ?>>Sindhi</option>
    <option value="Dogri" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Dogri' ? 'selected' : ''); ?>>Dogri</option>
    <option value="Kashmiri" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Kashmiri' ? 'selected' : ''); ?>>Kashmiri</option>
    <option value="Bodo" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Bodo' ? 'selected' : ''); ?>>Bodo</option>
    <option value="Santhali" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Santhali' ? 'selected' : ''); ?>>Santhali</option>
    <option value="Maithili" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Maithili' ? 'selected' : ''); ?>>Maithili</option>
    <option value="Santali" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Santali' ? 'selected' : ''); ?>>Santali</option>
    <option value="Kokborok" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Kokborok' ? 'selected' : ''); ?>>Kokborok</option>
    <option value="Khasi" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Khasi' ? 'selected' : ''); ?>>Khasi</option>
    <option value="Garo" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Garo' ? 'selected' : ''); ?>>Garo</option>
    <option value="Mizo" <?php echo e(old('mother_tongue', optional($profile)->mother_tongue) == 'Mizo' ? 'selected' : ''); ?>>Mizo</option>
</select>

                                    </div>
                                </div>



                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Select Height:</label>
                                       <select class="form-select" name="height">
    <option value="">Select Height</option>
    <option value="4ft 6in" <?php echo e(old('height', optional($profile)->height) == '4ft 6in' ? 'selected' : ''); ?>>4ft 6in</option>
    <option value="4ft 7in" <?php echo e(old('height', optional($profile)->height) == '4ft 7in' ? 'selected' : ''); ?>>4ft 7in</option>
    <option value="4ft 8in" <?php echo e(old('height', optional($profile)->height) == '4ft 8in' ? 'selected' : ''); ?>>4ft 8in</option>
    <option value="4ft 9in" <?php echo e(old('height', optional($profile)->height) == '4ft 9in' ? 'selected' : ''); ?>>4ft 9in</option>
    <option value="4ft 10in" <?php echo e(old('height', optional($profile)->height) == '4ft 10in' ? 'selected' : ''); ?>>4ft 10in</option>
    <option value="4ft 11in" <?php echo e(old('height', optional($profile)->height) == '4ft 11in' ? 'selected' : ''); ?>>4ft 11in</option>
    <option value="5ft 0in" <?php echo e(old('height', optional($profile)->height) == '5ft 0in' ? 'selected' : ''); ?>>5ft 0in</option>
    <option value="5ft 1in" <?php echo e(old('height', optional($profile)->height) == '5ft 1in' ? 'selected' : ''); ?>>5ft 1in</option>
    <option value="5ft 2in" <?php echo e(old('height', optional($profile)->height) == '5ft 2in' ? 'selected' : ''); ?>>5ft 2in</option>
    <option value="5ft 3in" <?php echo e(old('height', optional($profile)->height) == '5ft 3in' ? 'selected' : ''); ?>>5ft 3in</option>
    <option value="5ft 4in" <?php echo e(old('height', optional($profile)->height) == '5ft 4in' ? 'selected' : ''); ?>>5ft 4in</option>
    <option value="5ft 5in" <?php echo e(old('height', optional($profile)->height) == '5ft 5in' ? 'selected' : ''); ?>>5ft 5in</option>
    <option value="5ft 6in" <?php echo e(old('height', optional($profile)->height) == '5ft 6in' ? 'selected' : ''); ?>>5ft 6in</option>
    <option value="5ft 7in" <?php echo e(old('height', optional($profile)->height) == '5ft 7in' ? 'selected' : ''); ?>>5ft 7in</option>
    <option value="5ft 8in" <?php echo e(old('height', optional($profile)->height) == '5ft 8in' ? 'selected' : ''); ?>>5ft 8in</option>
    <option value="5ft 9in" <?php echo e(old('height', optional($profile)->height) == '5ft 9in' ? 'selected' : ''); ?>>5ft 9in</option>
    <option value="5ft 10in" <?php echo e(old('height', optional($profile)->height) == '5ft 10in' ? 'selected' : ''); ?>>5ft 10in</option>
    <option value="5ft 11in" <?php echo e(old('height', optional($profile)->height) == '5ft 11in' ? 'selected' : ''); ?>>5ft 11in</option>
    <option value="6ft 0in" <?php echo e(old('height', optional($profile)->height) == '6ft 0in' ? 'selected' : ''); ?>>6ft 0in</option>
    <option value="6ft 1in" <?php echo e(old('height', optional($profile)->height) == '6ft 1in' ? 'selected' : ''); ?>>6ft 1in</option>
    <option value="6ft 2in" <?php echo e(old('height', optional($profile)->height) == '6ft 2in' ? 'selected' : ''); ?>>6ft 2in</option>
    <option value="6ft 3in" <?php echo e(old('height', optional($profile)->height) == '6ft 3in' ? 'selected' : ''); ?>>6ft 3in</option>
    <option value="6ft 4in" <?php echo e(old('height', optional($profile)->height) == '6ft 4in' ? 'selected' : ''); ?>>6ft 4in</option>
    <option value="6ft 5in" <?php echo e(old('height', optional($profile)->height) == '6ft 5in' ? 'selected' : ''); ?>>6ft 5in</option>
    <option value="6ft 6in" <?php echo e(old('height', optional($profile)->height) == '6ft 6in' ? 'selected' : ''); ?>>6ft 6in</option>
    <option value="6ft 7in" <?php echo e(old('height', optional($profile)->height) == '6ft 7in' ? 'selected' : ''); ?>>6ft 7in</option>
    <option value="6ft 8in" <?php echo e(old('height', optional($profile)->height) == '6ft 8in' ? 'selected' : ''); ?>>6ft 8in</option>
    <option value="6ft 9in" <?php echo e(old('height', optional($profile)->height) == '6ft 9in' ? 'selected' : ''); ?>>6ft 9in</option>
    <option value="6ft 10in" <?php echo e(old('height', optional($profile)->height) == '6ft 10in' ? 'selected' : ''); ?>>6ft 10in</option>
    <option value="6ft 11in" <?php echo e(old('height', optional($profile)->height) == '6ft 11in' ? 'selected' : ''); ?>>6ft 11in</option>
    <option value="7ft 0in" <?php echo e(old('height', optional($profile)->height) == '7ft 0in' ? 'selected' : ''); ?>>7ft</option>
</select>



                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label class="lb">Marital Status:</label>
                                      <select class="form-select" name="marital_status">
    <option value="" <?php echo e(optional($profile)->marital_status ? '' : 'selected'); ?>>Select Marital Status</option>
    <option value="Never Married" <?php echo e(optional($profile)->marital_status === 'Never Married' ? 'selected' : ''); ?>>Never Married</option>
    <option value="Widowed" <?php echo e(optional($profile)->marital_status === 'Widowed' ? 'selected' : ''); ?>>Widowed</option>
    <option value="Divorced" <?php echo e(optional($profile)->marital_status === 'Divorced' ? 'selected' : ''); ?>>Divorced</option>
    <option value="Awaiting Divorce" <?php echo e(optional($profile)->marital_status === 'Awaiting Divorce' ? 'selected' : ''); ?>>Awaiting Divorce</option>
</select>




                                    </div>
                                </div>



                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Any Disability:</label>
<select class="form-select" name="disability">
    <option value="">Select</option>
    <option value="None" <?php echo e(optional($profile)->disability === 'None' ? 'selected' : ''); ?>>None</option>
    <option value="Physically Challenged" <?php echo e(optional($profile)->disability === 'Physically Challenged' ? 'selected' : ''); ?>>Physically Challenged</option>
</select>



                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Family Status:</label>
<select class="form-select" name="family_status">
    <option value="">Select Family Status</option>
    <option value="Middle Class" <?php echo e(optional($profile)->family_status === 'Middle Class' ? 'selected' : ''); ?>>Middle Class</option>
    <option value="High Class" <?php echo e(optional($profile)->family_status === 'High Class' ? 'selected' : ''); ?>>High Class</option>
    <option value="Upper Middle Class" <?php echo e(optional($profile)->family_status === 'Upper Middle Class' ? 'selected' : ''); ?>>Upper Middle Class</option>
    <option value="Rich / Affluent" <?php echo e(optional($profile)->family_status === 'Rich / Affluent' ? 'selected' : ''); ?>>Rich / Affluent</option>
</select>




                                    </div>
                                </div>





                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Family Type:</label>
  <select class="form-select" name="family_type">
    <option value="">Select Family Type</option>
    <option value="Joint Family" <?php echo e(optional($profile)->family_type === 'Joint Family' ? 'selected' : ''); ?>>Joint Family</option>
    <option value="Nuclear Family" <?php echo e(optional($profile)->family_type === 'Nuclear Family' ? 'selected' : ''); ?>>Nuclear Family</option>
</select>



                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label class="lb">Family Status:</label>
                                      <select class="form-select" name="family_value">
    <option value="">Select Family Value</option>
    <option value="Orthodox" <?php echo e(optional($profile)->family_value === 'Orthodox' ? 'selected' : ''); ?>>Orthodox</option>
    <option value="Moderate" <?php echo e(optional($profile)->family_value === 'Moderate' ? 'selected' : ''); ?>>Moderate</option>
    <option value="Traditional" <?php echo e(optional($profile)->family_value === 'Traditional' ? 'selected' : ''); ?>>Traditional</option>
    <option value="Liberal" <?php echo e(optional($profile)->family_value === 'Liberal' ? 'selected' : ''); ?>>Liberal</option>
</select>





                                    </div>
                                </div>

                                <?php

$educationLevels = [
    'No Formal Education', 'High School', 'Associate Degree', 'Bachelor\'s Degree', 'Master\'s Degree',
    'Doctorate', 'Professional Degree', 'Other'
];

                                ?>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <!-- Education -->
                                        <label class="lb">Education:</label>
                                        <select class="form-control" name="education">
                                            <option value="">Select Education Level</option>
                                            <?php $__currentLoopData = $educationLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($level); ?>" <?php echo e(old('education', optional($profile)->education) == $level ? 'selected' : ''); ?>>
                                                    <?php echo e($level); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <!-- Employed In -->
                                        <label class="lb">Employed In:</label>
                                       <select class="form-select" name="employed_in">
    <option value="">Select Employed In</option>
    <option value="Private" <?php echo e(optional($profile)->employed_in === 'Private' ? 'selected' : ''); ?>>Private</option>
    <option value="Government" <?php echo e(optional($profile)->employed_in === 'Government' ? 'selected' : ''); ?>>Government</option>
    <option value="Business" <?php echo e(optional($profile)->employed_in === 'Business' ? 'selected' : ''); ?>>Business</option>
    <option value="Self Employed" <?php echo e(optional($profile)->employed_in === 'Self Employed' ? 'selected' : ''); ?>>Self Employed</option>
    <option value="Not Working" <?php echo e(optional($profile)->employed_in === 'Not Working' ? 'selected' : ''); ?>>Not Working</option>
</select>

                                    </div>
                                </div>

                                <?php



                               $occupations = [
    'Accountant', 'Actor', 'Administrator', 'Agricultural Scientist', 'Airline Pilot', 'Artist', 'Banker',
    'Biologist', 'Business Analyst', 'Business Owner', 'Chemist', 'Civil Engineer', 'Computer Programmer',
    'Construction Worker', 'Consultant', 'Cook', 'Dentist', 'Doctor', 'Electrical Engineer', 'Engineer',
    'Financial Analyst', 'Graphic Designer', 'Healthcare Administrator', 'Human Resources Manager', 'IT Specialist',
    'Journalist', 'Lawyer', 'Librarian', 'Marketing Manager', 'Mathematician', 'Mechanic', 'Medical Researcher',
    'Nurse', 'Pharmacist', 'Photographer', 'Pilot', 'Plumber', 'Police Officer', 'Professor', 'Psychologist',
    'Public Relations Specialist', 'Research Scientist', 'Sales Manager', 'Software Developer', 'Teacher',
    'Veterinarian', 'Writer', 'Web Developer', 'Other', 'Administrative Officer', 'Agricultural Officer', 'Assistant Commissioner', 'Assistant Director',
    'Bank Probationary Officer', 'Civil Services Officer', 'Defense Services Officer', 'Diplomat',
    'Education Officer', 'Forest Ranger', 'Income Tax Officer', 'Inspector', 'Judicial Officer',
    'Lab Technician', 'Legislative Assistant', 'Police Inspector', 'Postal Services Officer',
    'Public Prosecutor', 'Revenue Officer', 'Research Officer', 'Revenue Inspector', 'Town Planner'
];


    // Annual income list (1 LPA to 10 LPA)
    $annualIncomes = [
        '1 LPA', '2 LPA', '3 LPA', '4 LPA', '5 LPA', '6 LPA', '7 LPA', '8 LPA', '9 LPA', '10 LPA'
    ];

                                ?>

                                <div class="row">
                                    <!-- user-profile-edit.blade.php -->

<div class="col-md-6 form-group">
    <!-- Occupation -->
    <label class="lb">Occupation:</label>
    <select class="form-control" name="occupation">
        <option value="">Select Occupation</option>
        <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($occupation); ?>" <?php echo e(old('occupation', optional($profile)->occupation) == $occupation ? 'selected' : ''); ?>>
                <?php echo e($occupation); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="col-md-6 form-group">
    <!-- Annual Income -->
    <label class="lb">Annual Income:</label>
    <select class="form-control" name="annual_income">
        <option value="">Select Annual Income</option>
        <?php $__currentLoopData = $annualIncomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($income); ?>" <?php echo e(old('annual_income', optional($profile)->annual_income) == $income ? 'selected' : ''); ?>>
                <?php echo e($income); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <!-- Work Location -->
                                        <label class="lb">Work Location:</label>
                                        <select class="form-control" name="work_location" id="work_location">
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($district); ?>"><?php echo e($district); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <!-- Residing State -->
                                        <label class="lb">Residing City:</label>
                                        <select class="form-control" name="residing_state" id="residing_state">
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($district); ?>"><?php echo e($district); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                </div>

                                






                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</section>



<style>
    .suggestions {
    border: 1px solid #ccc;
    max-height: 150px;
    overflow-y: auto;
    list-style: none;
    padding: 0;
    margin: 0;
    position: absolute;
    background: white;
    z-index: 1000;
}

.suggestions li {
    padding: 10px;
    cursor: pointer;
}

.suggestions li:hover {
    background-color: #f0f0f0;
}

</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/pages/user-profile-edit.blade.php ENDPATH**/ ?>