<?php $__env->startSection('dashboard-content'); ?>


<style>

button[type="submit"] {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    text-align: center;
    cursor: pointer;
    border: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}


button[type="submit"]:hover {
    background-color: #45a049;
}


/* Image Grid */
.login .container .row .inn .rhs .image-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

/* Image Container */
.login .container .row .inn .rhs .image-container {
    position: relative; /* Required for absolute positioning */
    width: 48%; /* Adjust the width of each image container */
    margin-bottom: 20px; /* Adjust the space between images */
}

/* Image */
.login .container .row .inn .rhs .image-container img {
    width: 100%; /* Ensure images fill their container */
    height: auto; /* Maintain aspect ratio */
    display: block; /* Remove default inline display */
}

/* Delete Button */
.login .container .row .inn .rhs .image-container .delete-btn {
    position: absolute;
    bottom: 10px; /* Adjust the distance from the bottom */
    left: 50%; /* Align button to the center horizontally */
    transform: translateX(-50%); /* Center the button */
    background-color: #dc3545; /* Red background color */
    color: #fff; /* White text color */
    border: none;
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
}

/* Media Query for Mobile Devices */
@media (max-width: 768px) {
    .login .container .row .inn .rhs .image-container {
        width: 100%; /* Make each image take full width on smaller screens */
    }
}

</style>
<section>
    <div class="login pro-edit-update">
        <div class="container">
            <div class="row">
                <div class="inn">
                    <div class="rhs">
                        <form action="<?php echo e(route('gallery.upload')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="images[]" multiple accept="image/*">
                            <button type="submit">Upload</button>
                        </form>
                    </div>


                </div>
            </div>
        </div>
    </div>


    <div class="login pro-edit-update">
    <div class="container">
        <div class="row">
            <div class="inn">
                <div class="rhs">
                    <!-- Image Grid -->
                    <div class="image-grid">
                        <!-- Image 1 -->
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="image-container">
                            <img src="<?php echo e(url($image->image_url)); ?>" alt="Image 1">
                            <a onclick="return confirm('Are you sure you want to Delete ?')" href="<?php echo e(route('gallery.delete', $image->id)); ?>">
                                <button class="btn btn-danger delete-btn"><i class="fa fa-trash"></i> Delete</button>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Repeat for Image 2, Image 3, and Image 4 -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</section>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/pages/upload-photo-gallery.blade.php ENDPATH**/ ?>