<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('code', '404'); ?>

<?php $__env->startSection('description'); ?>
    <?php echo e(__('The page you are looking for could not be found. The requested URL /:url was not found on this server.', ['url' => Request::path()])); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('Not Found')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/errors/404.blade.php ENDPATH**/ ?>