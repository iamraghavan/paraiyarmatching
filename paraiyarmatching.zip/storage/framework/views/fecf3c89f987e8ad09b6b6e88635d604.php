<?php $__env->startSection('content'); ?>
<?php

    $index = 0;
?>

<section>
    <div class="profi-pg profi-ban">
        <div class="">
            <div class="">
                <div class="profile">
                    <div class="pg-pro-big-im">
                        <div class="s1">
                            <img src="<?php echo e($user->profile_image); ?>" loading="lazy" class="pro" srcset="<?php echo e($user->profile_image); ?>" alt="<?php echo e($user->name); ?>">
                        </div>

                    </div>
                </div>
                <div class="profi-pg profi-bio">
                    <div class="lhs">
                        <div class="pro-pg-intro">
                            <h1><?php echo e($user->name); ?></h1>
                            <div class="pro-info-status">
                                <span class="stat-1"><b><?php echo e(rand(100, 999)); ?></b> Profile Viewers</span>

                            </div>
                            <ul>
                                <li>
                                    <div>
                                        <img src="images/icon/pro-city.png" loading="lazy" alt="">
                                        <span>City: <strong><?php echo e($user->residing_state); ?></strong></span>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <img src="images/icon/pro-age.png" loading="lazy" alt="">
                                        <span>Age: <strong><?php echo e(\Carbon\Carbon::parse($user->dob)->age); ?></strong></span>

                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <img src="images/icon/pro-city.png" loading="lazy" alt="">
                                        <span>Height: <strong><?php echo e($user->height); ?></strong></span>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <img src="images/icon/pro-city.png" loading="lazy" alt="">
                                        <span>Job: <strong><?php echo e($user->employed_in); ?></strong></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!-- PROFILE ABOUT -->
                        <div class="pr-bio-c pr-bio-abo">
                            <h3>About</h3>
                            <p class="text-justify"><?php echo e($user->my_bio); ?></p>
                        </div>
                        <!-- END PROFILE ABOUT -->
                        <!-- PROFILE ABOUT -->
                        <div class="pr-bio-c pr-bio-gal" id="gallery">Paraiyar Matching - The No. 1 Matrimony Site for Tamil Peoples - paraiyarmatching.com
                            <h3>Photo gallery</h3>
                            <div id="image-gallery">
                                <?php if($user->photo_gallery && $user->photo_gallery->count() > 0): ?>
                                    <?php $__currentLoopData = $user->photo_gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pro-gal-imag">
                                            <a href="<?php echo e($image->image_url); ?>" target="_blank">
                                            <div class="img-wrapper">

                                                    <img src="<?php echo e($image->image_url); ?>" class="img-responsive"  alt="<?php echo e(strtolower($user->name) . ' ' . ($index + 1) . ' profile'); ?>">

                                                <div class="img-overlay" style="opacity: 0;">
                                                    <i class="fa fa-arrows-alt" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>No images available</p>
                                <?php endif; ?>
                            </div>

                        <div id="overlay" style="display: none;"><div id="prevButton"><i class="fa fa-angle-left" aria-hidden="true"></i></div><img><div id="nextButton"><i class="fa fa-angle-right" aria-hidden="true"></i></div><div id="exitButton"><i class="fa fa-times" aria-hidden="true"></i></div></div></div>
                        <!-- END PROFILE ABOUT -->
                        <!-- PROFILE ABOUT -->
                        <div class="pr-bio-c pr-bio-conta">
                            <h3>Contact info</h3>
                            <ul>
                                <li><span><i class="fa fa-mobile" aria-hidden="true"></i><b>Phone:</b><?php echo e($user->phone); ?></span></li>
                                <li><span><i class="fa fa-envelope-o" aria-hidden="true"></i><b>Email:</b><?php echo e($user->email); ?></span>
                                </li>
                                <li><span><i class="fa fa fa-map-marker" aria-hidden="true"></i><b>Address: </b><?php echo e($user->residing_state); ?> /
                                    <b>Work Address: </b><?php echo e($user->work_location); ?>

                                </span></li>
                            </ul>
                        </div>
                        <!-- END PROFILE ABOUT -->
                        <!-- PROFILE ABOUT -->
                        <div class="pr-bio-c pr-bio-info">
                            <h3>Personal information</h3>
                            <ul>
                                <?php if(isset($user->user_pmid)): ?>
                                    <li><b>User PM ID:</b> <?php echo e($user->user_pmid); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->age)): ?>
                                    <li><b>Age:</b> <?php echo e($user->age); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->dob)): ?>
                                    <li><b>Date of Birth:</b> <?php echo e(\Carbon\Carbon::parse($user->dob)->format('d M Y')); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->religion)): ?>
                                    <li><b>Religion:</b> <?php echo e($user->religion); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->mother_tongue)): ?>
                                    <li><b>Mother Tongue:</b> <?php echo e($user->mother_tongue); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->height)): ?>
                                    <li><b>Height:</b> <?php echo e($user->height); ?> cm</li>
                                <?php endif; ?>

                                <?php if(isset($user->marital_status)): ?>
                                    <li><b>Marital Status:</b> <?php echo e($user->marital_status); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->disability)): ?>
                                    <li><b>Disability:</b> <?php echo e($user->disability); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->family_status)): ?>
                                    <li><b>Family Status:</b> <?php echo e($user->family_status); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->family_type)): ?>
                                    <li><b>Family Type:</b> <?php echo e($user->family_type); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->family_value)): ?>
                                    <li><b>Family Value:</b> <?php echo e($user->family_value); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->education)): ?>
                                    <li><b>Education:</b> <?php echo e($user->education); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->employed_in)): ?>
                                    <li><b>Employed In:</b> <?php echo e($user->employed_in); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->occupation)): ?>
                                    <li><b>Occupation:</b> <?php echo e($user->occupation); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->annual_income)): ?>
                                    <li><b>Annual Income:</b> <?php echo e($user->annual_income); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->work_location)): ?>
                                    <li><b>Work Location:</b> <?php echo e($user->work_location); ?></li>
                                <?php endif; ?>

                                <?php if(isset($user->residing_state)): ?>
                                    <li><b>Residing State:</b> <?php echo e($user->residing_state); ?></li>
                                <?php endif; ?>


<div class="mt-4" style="margin: 1.5rem 0 !important">
    <?php if(isset($user->star)): ?>
    <li><b>Star</b> <?php echo e($user->star); ?></li>
<?php endif; ?>
<?php if(isset($user->raasi)): ?>
<li><b>Rassi:</b> <?php echo e($user->raasi); ?></li>
<?php endif; ?>





<?php if(isset($user->dosham)): ?>
<li><b>Dosham:</b> <?php echo e($user->dosham); ?></li>
<?php endif; ?>
<?php if(isset($user->diet)): ?>
<li><b>Diet:</b> <?php echo e($user->diet); ?></li>
<?php endif; ?>

</div>

                            </ul>


<br>




                        </div>

                        <?php if(isset($user->siblings)): ?>
    <?php
        $siblings = json_decode($user->siblings, true);
    ?>

    <div class="">
        <?php if(isset($user->number_of_siblings)): ?>
            <div class="row mb-2">
                <div class="col-12">
                    <li><b>No of Siblings:</b> <?php echo e($user->number_of_siblings); ?></li>
                </div>
            </div>
        <?php endif; ?>

        <?php if(is_array($siblings)): ?>
            <?php $__currentLoopData = $siblings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-2 sibling-info">
                    <div class="col-6">
                        <b>Name:  </b>   <?php echo e($sibling['name']); ?>

                    </div>
                    <div class="col-6">
                        <b>Married:  </b>   <?php echo e($sibling['married'] ? 'Yes' : 'No'); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php endif; ?>





<div class="">




            <div class="row mb-2 sibling-info">
                <?php if(isset($user->father_name)): ?>
                <div class="col-6">

                    <b>Fathers Name:</b> <?php echo e($user->father_name); ?>


                </div>
                <?php endif; ?>

                <?php if(isset($user->father_occupation)): ?>
                <div class="col-6">
                <b>Fathers Occupation:</b> <?php echo e($user->father_occupation); ?>

                </div>
                <?php endif; ?>
            </div>




            <div class="row mb-2 sibling-info">

                    <?php if(isset($user->mother_name)): ?>
                    <div class="col-6">
                    <b>Mother Name:</b> <?php echo e($user->mother_name); ?>

                    </div>
                    <?php endif; ?>

                <?php if(isset($user->mother_occupation)): ?>
                <div class="col-6">
                <b>Mother Occupation:</b> <?php echo e($user->mother_occupation); ?>

                </div>
                <?php endif; ?>
            </div>


</div>

<style>
.sibling-info {
    background-color: #f8f9fa;
    border: 1px solid #dee2e6;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 10px;
}

.sibling-info .col-6 {
    display: flex;
    align-items: center;
}

@media (max-width: 767px) {
    .sibling-info .col-6 {
        flex: 0 0 100%;
        max-width: 100%;
        margin-bottom: 10px;
    }

    .col-12 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

/* Adjusting container and other elements */
.container {
    padding-left: 15px;
    padding-right: 15px;
}

</style>

                        <!-- END PROFILE ABOUT -->
                        <!-- PROFILE ABOUT -->
                        
                        <!-- END PROFILE ABOUT -->
                        <!-- PROFILE ABOUT -->
                        
                        <!-- END PROFILE ABOUT -->


                    </div>

                    <!-- PROFILE lHS -->
                    <div class="rhs">
                        <!-- HELP BOX -->

                        <!-- END HELP BOX -->
                        <!-- RELATED PROFILES -->


                        



                        <!-- END RELATED PROFILES -->
                    </div>
                    <!-- END PROFILE lHS -->
                </div>
            </div>
        </div>
    </div>
</section>

<div class="col-lg-12" style="margin: 20rem">

    <img src="<?php echo e($user->profile_image); ?>" alt="<?php echo e($user->name); ?>" srcset="">

    <h1><?php echo e($user->name); ?></h1>
    <p>Age: <?php echo e($user->age); ?></p>
    <p>Religion: <?php echo e($user->religion); ?></p>
    <p>City: <?php echo e($user->residing_state); ?></p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/profile-information.blade.php ENDPATH**/ ?>