<?php echo e($slot); ?>

<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>