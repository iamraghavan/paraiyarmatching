<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="index, follow">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
        <link rel="manifest" href="/site.webmanifest">
        <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#404040">
        <meta name="apple-mobile-web-app-title" content="Paraiyar Matching">
        <meta name="application-name" content="Paraiyar Matching">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="theme-color" content="#ffffff">

        

            <?php echo e(seo()->render()); ?>

            <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>


            <script type="application/ld+json">
                {
                  "@context": "https://schema.org",
                  "@type": "Organization",
                  "name": "Paraiyar Matching",
                  "logo": "<?php echo e(asset('images/logo-b.png')); ?>",
                  "description": "Paraiyar Matching: No. 1 site for Tamil Brides & Grooms. Trusted globally. Register free!",
                  "contactPoint": {
                    "@type": "ContactPoint",
                    "telephone": "918667090188",
                    "email": "info@paraiyarmatching.com"
                  }
                }
                </script>


                <script type="application/ld+json">
                    {
                        "@context": "http://schema.org/",
                        "@type": "LocalBusiness",
                        "name": "Paraiyar Matching",
                        "image": "<?php echo e(asset('images/logo-b.png')); ?>",
                        "priceRange": "3000",
                        "telephone": "918667090188",
                        "url": "Request::path()",
                        "address": {
                            "@type": "PostalAddress",
                            "streetAddress": "Ambattur Industrial Estate",
                            "addressLocality": "Chennai",
                            "addressRegion": "Tamil Nadu",
                            "postalCode": "600053",
                            "addressCountry": "IN"
                        },
                        "openingHoursSpecification": [
                            {
                                "@type": "OpeningHoursSpecification",
                                "dayOfWeek": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                                "opens": "00:00",
                                "closes": "12:00"
                            },
                            {
                                "@type": "OpeningHoursSpecification",
                                "dayOfWeek": [],
                                "opens": "",
                                "closes": ""
                            }
                        ]
                    }
                    </script>

        <link rel="stylesheet" href="<?php echo e(asset("/css/bootstrap.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/css/font-awesome.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/css/animate.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/css/style.css")); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.css">

    <style>
          .cta {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
            text-decoration: none;
            margin-top: 10px;
        }
        .cta:hover {
            background-color: #0056b3;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            text-align: center;
            border-radius: 8px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .modal img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }
    </style>

    
    <style>
        /* Hide the block on mobile devices */
@media (max-width: 768px) {
    .desktop-view {
        display: none;
    }
}

    </style>



    </head>
    <body>


        <?php if (isset($component)) { $__componentOriginal9b0da1ce4a7273760fcbfd5667774437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437 = $attributes; } ?>
<?php $component = App\View\Components\Loader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $attributes = $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $component = $__componentOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale1bd8886b3051f86a33a357192c57a17 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1bd8886b3051f86a33a357192c57a17 = $attributes; } ?>
<?php $component = App\View\Components\HeaderTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeaderTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $attributes = $__attributesOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__attributesOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $component = $__componentOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__componentOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>



        <?php echo $__env->yieldContent('content'); ?>


        <?php if(session('alert')): ?>
        <div class="alert alert-warning">
            <?php echo e(session('alert')); ?>

        </div>
    <?php endif; ?>




<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        icon: 'success',
        buttons: false,
        timer: 3000,
        showConfirmButton: false,
        showCloseButton: true,
        animation: true
    });
</script>

<?php endif; ?>


<?php if(session('error')): ?>
<script>
    Swal.fire({
        title: 'Error!',
        text: '<?php echo e(session('error')); ?>',
        icon: 'error',
        buttons: false,
        timer: 3000,
        showConfirmButton: false,
        showCloseButton: true,
        animation: true
    });
</script>
<?php endif; ?>



<!-- Modal HTML -->



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <script src="<?php echo e(asset("/js/jquery.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/popper.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/bootstrap.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/select-opt.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/slick.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/custom.min.js")); ?>"></script>



 <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

    </body>
</html>
<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/layouts/app.blade.php ENDPATH**/ ?>