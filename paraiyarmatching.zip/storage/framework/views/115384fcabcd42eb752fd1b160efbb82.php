<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Paraiyar Matching - Matchfinder is a matchmaking portal for brides and grooms </title>

    <link rel="stylesheet" href="<?php echo e(asset("/css/bootstrap.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/font-awesome.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/animate.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/style.css")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.css">




    </head>
    <body>


        <?php if (isset($component)) { $__componentOriginal9b0da1ce4a7273760fcbfd5667774437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437 = $attributes; } ?>
<?php $component = App\View\Components\Loader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $attributes = $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $component = $__componentOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale1bd8886b3051f86a33a357192c57a17 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1bd8886b3051f86a33a357192c57a17 = $attributes; } ?>
<?php $component = App\View\Components\HeaderTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeaderTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $attributes = $__attributesOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__attributesOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $component = $__componentOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__componentOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>



        <?php echo $__env->yieldContent('content'); ?>



<?php if(session('success')): ?>
<script>
    swal({
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        icon: 'success',
        buttons: false,
        timer: 3000,
        showConfirmButton: false,
        showCloseButton: true,
        animation: true
    });
</script>

<?php endif; ?>


<?php if(session('error')): ?>
<script>
    swal({
        title: 'Error!',
        text: '<?php echo e(session('error')); ?>',
        icon: 'error',
        buttons: false,
        timer: 3000,
        showConfirmButton: false,
        showCloseButton: true,
        animation: true
    });
</script>
<?php endif; ?>



<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <script src="<?php echo e(asset("/js/jquery.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/popper.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/bootstrap.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/select-opt.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/slick.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/custom.js")); ?>"></script>


        <script>
            // Function to handle logout click event
            function confirmLogout() {
                // Show SweetAlert confirmation dialog
                Swal.fire({
                    title: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    // Handle confirmation result
                    if (result.isConfirmed) {
                        window.location.href = '/app/logout'; // Redirect to logout URL
                    }
                });
            }
        </script>


    </body>
</html>
<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/layouts/app.blade.php ENDPATH**/ ?>