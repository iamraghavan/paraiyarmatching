<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e($user->name); ?> - <?php echo e($user->pmid); ?> - Paraiyar Matching - Matchfinder for brides and grooms </title>

        

    <link rel="stylesheet" href="<?php echo e(asset("/css/bootstrap.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/font-awesome.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/animate.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/css/style.css")); ?>">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.css">





    </head>
    <body>


        <?php if (isset($component)) { $__componentOriginal9b0da1ce4a7273760fcbfd5667774437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437 = $attributes; } ?>
<?php $component = App\View\Components\Loader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Loader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $attributes = $__attributesOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__attributesOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437)): ?>
<?php $component = $__componentOriginal9b0da1ce4a7273760fcbfd5667774437; ?>
<?php unset($__componentOriginal9b0da1ce4a7273760fcbfd5667774437); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale1bd8886b3051f86a33a357192c57a17 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1bd8886b3051f86a33a357192c57a17 = $attributes; } ?>
<?php $component = App\View\Components\HeaderTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeaderTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $attributes = $__attributesOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__attributesOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1bd8886b3051f86a33a357192c57a17)): ?>
<?php $component = $__componentOriginale1bd8886b3051f86a33a357192c57a17; ?>
<?php unset($__componentOriginale1bd8886b3051f86a33a357192c57a17); ?>
<?php endif; ?>



        <?php echo $__env->yieldContent('dashboard-content'); ?>




        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        
        <script src="<?php echo e(asset("/js/jquery.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/popper.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/bootstrap.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/select-opt.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/slick.js")); ?>"></script>
        <script src="<?php echo e(asset("/js/custom.min.js")); ?>"></script>
        <?php if(session('success')): ?>
        <script>
            Swal.fire({
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success',
                buttons: false,
                timer: 3000,
                showConfirmButton: false,
                showCloseButton: true,
                animation: true
            });
        </script>

        <?php endif; ?>


        <?php if(session('info')): ?>
        <script>
            Swal.fire({
                title: 'Information !',
                text: '<?php echo e(session('info')); ?>',
                icon: 'info',
                buttons: false,
                timer: 3000,
                showConfirmButton: false,
                showCloseButton: true,
                animation: true
            });
        </script>

        <?php endif; ?>




        <?php if(session('error')): ?>
        <script>
            Swal.fire({
                title: 'error !',
                text: '<?php echo e(session('error')); ?>',
                icon: 'error',
                buttons: false,
                timer: 3000,
                showConfirmButton: false,
                showCloseButton: true,
                animation: true
            });
        </script>

        <?php endif; ?>

        <script>

const dobInput = document.getElementById('dob');
const ageInput = document.getElementById('age');

// Add event listener for date of birth change
dobInput.addEventListener('change', function() {
    // Calculate age
    let dob = new Date(this.value);
    let today = new Date();
    let age = today.getFullYear() - dob.getFullYear();

    // Check if the birthday hasn't occurred yet this year
    if (today.getMonth() < dob.getMonth() || (today.getMonth() === dob.getMonth() && today.getDate() < dob.getDate())) {
        age--;
    }

    // Update the age input value
    ageInput.value = age;

    // Check if the user is below 18 years old
    if (age < 18) {
        // Show a confirmation message before logout
        Swal.fire({
            title: 'You are below 18 years old.',
            text: 'You will be logged out in 2 seconds | You are not allowed to continue with your profile.',
            icon: 'warning',
            timer: 2000,
            timerProgressBar: true,
            showConfirmButton: false,
            willClose: () => {
                // Perform logout after confirmation message is closed
                window.location.href = '/app/logout';
            }
        });
    }
});

        </script>


        <script>
            // Function to handle logout click event
            function confirmLogout() {
                // Show SweetAlert confirmation dialog
                Swal.fire({
                    title: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    // Handle confirmation result
                    if (result.isConfirmed) {
                        window.location.href = '/app/logout'; // Redirect to logout URL
                    }
                });
            }
        </script>
<!-- Include Toastr library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
    // Function to check if all required fields are filled
    function validateForm() {
        // Check if profile image is selected
        var profileImage = document.getElementById('profile_image');
        if (profileImage.type === 'file' && !profileImage.value) {
            return true; // No file selected, but allow form submission
        }

        // Check if any input field is empty
        var inputs = document.querySelectorAll('input[type=text], input[type=email], input[type=number], input[type=date], select');
        for (var i = 0; i < inputs.length; i++) {
            var input = inputs[i];
            if (!input.value.trim()) {
                var fieldName = input.previousElementSibling.textContent.replace(':', '');
                toastr.error(fieldName + ' is empty.', 'Error');
                return false;
            }
        }

        return true;
    }

    // Attach event listener for form submission
    const form = document.querySelector('form');
if (form) {
    form.addEventListener('submit', function(event) {
        if (!validateForm()) {
            // Prevent form submission if validation fails
            event.preventDefault();
        }
    });
} else {
    console.error('Form element not found. Event listener not added.');
}

// Function to validate the form
function validateForm() {
    // Add your form validation logic here
    // Return true if the form is valid, false otherwise
    return true; // Placeholder, replace with actual validation logic
}
</script>

<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>


    </body>
</html>
<?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/pages/dashboard/layouts/app.blade.php ENDPATH**/ ?>