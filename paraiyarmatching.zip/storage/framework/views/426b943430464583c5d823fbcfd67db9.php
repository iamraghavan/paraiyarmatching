<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
<!-- LOGIN -->
<section>
    <div class="login">
        <div class="container">
            <div class="row">

                <div class="inn">
                    <div class="lhs">
                        <div class="tit">
                            <h2>Now <b>Find <br> your life partner</b> Easy and fast.</h2>
                        </div>
                        <div class="im">
                            <img src="images/login-couple.png" alt="">
                        </div>
                        <div class="log-bg">&nbsp;</div>
                    </div>
                    <div class="rhs">
                        <div>
                            <div class="form-tit">
                                <h4>Start for free</h4>
                                <h1>Sign in to Matrimony</h1>
                                <p>Not a member? <a href="<?php echo e(url('/app/register')); ?>">Sign up now</a></p>
                            </div>
                            <?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

                            <div class="form-login">
                                <form method="POST" action="<?php echo e(route('verify_login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label class="lb">Email:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="lb">Password:</label>
                                        <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required>
                                    </div>

                                    <div class="form-group">
                                        <?php if (isset($component)) { $__componentOriginale9d0814dccb09ead38d4e1f9dcb45674 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9d0814dccb09ead38d4e1f9dcb45674 = $attributes; } ?>
<?php $component = RyanChandler\LaravelCloudflareTurnstile\View\Components\Turnstile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('turnstile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\RyanChandler\LaravelCloudflareTurnstile\View\Components\Turnstile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-action' => 'login','data-cdata' => 'sessionid-123456789','data-callback' => 'callback','data-expired-callback' => 'expiredCallback','data-error-callback' => 'errorCallback','data-theme' => 'light','data-tabindex' => '1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9d0814dccb09ead38d4e1f9dcb45674)): ?>
<?php $attributes = $__attributesOriginale9d0814dccb09ead38d4e1f9dcb45674; ?>
<?php unset($__attributesOriginale9d0814dccb09ead38d4e1f9dcb45674); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9d0814dccb09ead38d4e1f9dcb45674)): ?>
<?php $component = $__componentOriginale9d0814dccb09ead38d4e1f9dcb45674; ?>
<?php unset($__componentOriginale9d0814dccb09ead38d4e1f9dcb45674); ?>
<?php endif; ?>
                                    </div>


                                    <div class="form-group form-check">
                                        <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                                    </div>



                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <button type="submit" class="btn btn-primary">Sign in</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\paraiyarmatching\resources\views/auth/login.blade.php ENDPATH**/ ?>